// main function
fun main() {
    val color : Color = Color.BLUE
    print(color)
}

enum class Color{
    RED, GREEN, BLUE
}